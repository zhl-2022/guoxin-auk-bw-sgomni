"""Measure a declared96-request TTS HTTP workload on the unchanged AuK profile.

This is serving performance, not another accuracy sample or organizer acceptance.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import base64
import datetime as dt
import hashlib
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
import wave
import zipfile

STAGE = Path('/root/private_data/guoxin-session019/auk-zhhard-stage001')
OUT = Path('/root/private_data/guoxin-session030/auk-performance-A001')
BASELINE = Path('/root/auk030-zhhard-B-fixed-config.json')


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--data', type=Path, default=STAGE / 'data')
    args = parser.parse_args()
    data = args.data
    assert sha(data / 'samples.jsonl') == 'ea61e12ac36e6c1520a7c41ed608ebcbc7471933d47f5964b1e5dde02cc98701'
    all_rows = [json.loads(line) for line in (data / 'samples.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(all_rows) == 400
    selected = sorted((r for r in all_rows if 1 <= r['estimated_output_seconds'] <= 15), key=lambda r: r['id'])[:16]
    assert len(selected) == 16
    plan = {'scope': 'Fixed short-form TTS serving workload; not accuracy resampling', 'selected_ids': [r['id'] for r in selected],
            'selection': 'First16 IDs in the complete400 dataset with declared estimated duration1..15s; chosen before performance requests',
            'concurrencies': [1, 2, 4], 'rounds': 2, 'requests_per_group': 16, 'measured_requests': 96,
            'separate_warmup_requests': 6, 'max_seconds_service_profile': 100,
            'TTFA_boundary': 'Client first response-body byte; server buffers generated WAV, not a streaming speech token measure',
            'official_acceptance': False, 'GPU_started': False}
    if args.plan_only:
        print(json.dumps(plan, indent=2))
        return
    assert socket.gethostname() == 'crdnotebook-2112186448839770114-ac3p4mowhz-97046'
    image = json.loads(Path('/root/robo030-final-image-ready-observed.json').read_text())
    assert image['region_ready'] and image['all_image_operations_complete']
    for port in (30000, 30001, 30002, 30109, 30119, 30129, 30139):
        with socket.socket() as sock:
            sock.settimeout(1)
            assert sock.connect_ex(('127.0.0.1', port)) != 0, 'Existing model left untouched'
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / 'executed-controller.py').write_bytes(Path(__file__).read_bytes())
    (OUT / 'workload-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    candidate = OUT / 'candidate'
    shutil.copytree(STAGE / 'candidate', candidate)
    assert sha(candidate / 'serve.py') == 'a7464a867538ebc9e9061dcd411874f5900fcb2ca529db973d7bc428f4051fe7'
    assert sha(candidate / 'model-lock.json') == '56327414733b1e99c2b43e0e7b4438faf844caaf2f71cc87c9743dd3caf38934'
    env = os.environ.copy()
    env.update(AUK_MAX_SECONDS='100', AUK_MAX_RUNTIME_SECONDS='10800', AUK_LOAD_TIMEOUT='1200',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', ROCM_PATH='/opt/dtk', HIP_PATH='/opt/dtk/hip')
    env['PATH'] = '/opt/ucx/bin:/opt/dtk/bin:/opt/dtk/llvm/bin:/opt/dtk/hip/bin:/opt/hyhal/bin:' + env.get('PATH', '/usr/bin:/bin')
    env['LD_LIBRARY_PATH'] = ':'.join(['/opt/ucx/lib', '/opt/dtk/dcc/gcvm/lib', '/opt/dtk/hip/lib',
        '/opt/dtk/llvm/lib', '/opt/dtk/lib', '/opt/dtk/lib64', '/opt/hyhal/lib', '/opt/hyhal/lib64',
        '/opt/dtk/dushmem/lib', '/opt/dtk/opencl/lib', '/opt/mpi/lib', '/opt/hwloc/lib', env.get('LD_LIBRARY_PATH', '')])
    run_id = uuid.uuid4().hex
    record = {'started_utc': now(), 'controller_pid': os.getpid(), 'source_sha256': sha(__file__),
              'state': 'launching_same_AuK_profile', 'run_id': run_id, 'phases': {},
              'measured_requests': 0, 'groups': [], 'accuracy_evaluation_requests': 0,
              'new_notebooks_started': 0, 'technical_delivery_complete': False, 'submitted': False}
    def save():
        p = OUT / 'progress.tmp'
        p.write_text(json.dumps(record, indent=2) + '\n')
        p.replace(OUT / 'progress.json')
    def step(action, seconds):
        with (OUT / (action + '.log')).open('xb') as log:
            p = subprocess.run([sys.executable, str(candidate / 'runtime.py'), action, '--run-id', run_id],
                               env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=seconds)
        record['phases'][action] = p.returncode
        save()
        return p.returncode
    save()
    try:
        assert step('launch', 1500) == 0
        current = json.loads((candidate / 'runtime' / ('config-' + run_id + '.json')).read_text())
        old = json.loads(BASELINE.read_text())
        def normalize(value, task, identity):
            if isinstance(value, dict):
                return {k: normalize(v, task, identity) for k, v in value.items() if k != 'run_id'}
            if isinstance(value, list):
                return [normalize(v, task, identity) for v in value]
            return value.replace(task, '__TASK__').replace(identity, '__RUN__') if isinstance(value, str) else value
        assert normalize(current, current['task'], run_id) == normalize(old, old['task'], old['run_id'])
        record.update(state='measuring_fixed96_TTS_requests', actual_profile_matches_complete1200_generation=True)
        save()
        def request(sample, directory):
            assert sha(data / sample['audio']) == sample['sha256']
            body = {'model': 'tencent-auk-bw-port006', 'input': sample['text'], 'ref_text': sample['ref_text'],
                    'ref_audio': 'data:audio/wav;base64,' + base64.b64encode((data / sample['audio']).read_bytes()).decode(),
                    'seed': 1234, 'response_format': 'wav'}
            raw = json.dumps(body).encode()
            started = time.perf_counter()
            req = urllib.request.Request('http://127.0.0.1:30139/v1/audio/speech', raw, {'Content-Type': 'application/json'})
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=900) as response:
                first = response.read(1)
                first_at = time.perf_counter()
                audio = first + response.read(64 * 1024**2)
            finished = time.perf_counter()
            path = directory / (sample['id'] + '.wav')
            with path.open('xb') as stream:
                stream.write(audio)
            with wave.open(io.BytesIO(audio), 'rb') as wav:
                assert wav.getnchannels() == 1 and wav.getsampwidth() == 2 and wav.getframerate() == 24000
                seconds = wav.getnframes() / 24000
                assert seconds > 0
            return {'id': sample['id'], 'request_sha256': hashlib.sha256(raw).hexdigest(),
                    'response_sha256': hashlib.sha256(audio).hexdigest(), 'response_bytes': len(audio),
                    'audio_seconds': seconds, 'wall_seconds': finished - started,
                    'first_body_byte_seconds': first_at - started, 'RTF': (finished - started) / seconds}
        for round_no in (1, 2):
            for concurrency in (1, 2, 4):
                target = OUT / f'round{round_no}_c{concurrency}'
                target.mkdir()
                warm = target / 'warmup'
                warm.mkdir()
                warm_row = request(selected[0], warm)
                (target / 'warmup.json').write_text(json.dumps(warm_row, indent=2) + '\n')
                audio = target / 'audio'
                audio.mkdir()
                started = time.perf_counter()
                with ThreadPoolExecutor(max_workers=concurrency) as pool:
                    rows = list(pool.map(lambda sample: request(sample, audio), selected))
                elapsed = time.perf_counter() - started
                with (target / 'requests.jsonl').open('x') as stream:
                    for row in rows:
                        stream.write(json.dumps(row) + '\n')
                total_audio = sum(r['audio_seconds'] for r in rows)
                result = {'round': round_no, 'concurrency': concurrency, 'requests': len(rows),
                          'wall_seconds': elapsed, 'audio_seconds': total_audio,
                          'RTFX': total_audio / elapsed, 'requests_per_second': len(rows) / elapsed,
                          'mean_RTF': sum(r['RTF'] for r in rows) / len(rows),
                          'mean_first_body_byte_seconds': sum(r['first_body_byte_seconds'] for r in rows) / len(rows)}
                (target / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
                record['groups'].append(result)
                record['measured_requests'] += len(rows)
                save()
        assert record['measured_requests'] == 96
        record['performance_complete'] = True
    except BaseException as exc:
        record['performance_error'] = repr(exc)
    finally:
        try:
            step('stop', 120)
        except BaseException as exc:
            record['cleanup_error'] = repr(exc)
        with socket.socket() as sock:
            record['owned_service_stopped'] = sock.connect_ex(('127.0.0.1', 30139)) != 0
        record.update(state='performance_complete_pending_independent_audit' if record.get('performance_complete') else 'performance_or_cleanup_failed', ended_utc=now())
        save()
    rows = []
    with zipfile.ZipFile('/root/session030-auk-performance-A001.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=1) as bundle:
        for folder, dirs, names in os.walk(OUT, onerror=lambda error: (_ for _ in ()).throw(error)):
            dirs[:] = sorted(n for n in dirs if n != '__pycache__')
            for name in sorted(names):
                path = Path(folder) / name
                assert not path.is_symlink()
                rel = path.relative_to(OUT).as_posix()
                bundle.write(path, rel)
                rows.append({'path': rel, 'bytes': path.stat().st_size, 'sha256': sha(path)})
        bundle.writestr('MANIFEST.json', json.dumps({'files': rows}, indent=2))
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()
